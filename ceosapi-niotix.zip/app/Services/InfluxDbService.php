<?php

namespace App\Services;

use App\Services\Niotix\NiotixApiClient;
use Illuminate\Http\Client\ConnectionException;

class InfluxDbService
{
    protected NiotixApiClient $niotixApiClient;

    public function __construct(
        NiotixApiClient $niotixApiClient
    )
    {
        $this->niotixApiClient = $niotixApiClient;
    }

    /**
     * @throws ConnectionException
     */
    public function query(array $data): array
    {
        $query = $this->buildQuery($data);

        return $this->niotixApiClient->post(
            'influxdb/query',
            [
                'epoch' => 'ms',
                'q' => $query,
            ]
        );
    }

    private function buildQuery(array $data): string
    {
        $sql = sprintf(
            'SELECT %s("%s") FROM "%s"',
            strtoupper($data['aggregation']),
            $data['field'],
            $data['measurement']
        );

        $where = [];

        if (!empty($data['dtwin_title'])) {
            $where[] = sprintf(
                '"dtwin_title" = \'%s\'',
                $data['dtwin_title']
            );
        }

        if (!empty($data['dtwin_id'])) {
            $where[] = sprintf(
                '"dtwin_id" = \'%s\'',
                $data['dtwin_id']
            );
        }

        if (!empty($data['state_identifier'])) {
            $where[] = sprintf(
                '"state_identifier" = \'%s\'',
                $data['state_identifier']
            );
        }

        $where[] = sprintf(
            'time >= %dms',
            $data['from']
        );

        $where[] = sprintf(
            'time <= %dms',
            $data['to']
        );

        $sql .= ' WHERE ' . implode(' AND ', $where);

        if (!empty($data['group_by'])) {
            $sql .= sprintf(
                ' GROUP BY time(%s)',
                $data['group_by']
            );
        }

        if (!empty($data['fill'])) {
            $sql .= sprintf(
                ' FILL(%s)',
                $data['fill']
            );
        }

        return $sql;
    }
}
