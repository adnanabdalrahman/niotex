<?php

namespace App\Http\Requests\InfluxDb;

use Illuminate\Foundation\Http\FormRequest;

class QueryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'measurement' => ['required', 'string'],
            'field' => ['required', 'string'],
            'aggregation' => ['required', 'string'],
            'dtwin_title' => ['nullable', 'string'],
            'dtwin_id' => ['nullable', 'integer'],
            'state_identifier' => ['nullable', 'string'],
            'from' => ['required', 'integer'],
            'to' => ['required', 'integer'],
            'group_by' => ['nullable', 'string'],
            'fill' => ['nullable', 'string'],
            'epoch' => ['nullable', 'in:h,m,s,ms,u,ns'],
        ];
    }
}
